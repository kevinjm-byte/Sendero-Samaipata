# Senderos Samaipata — sitio web

Sitio del operador de turismo **Senderos Samaipata** (Samaipata, Santa Cruz, Bolivia), desarrollado en la materia
Diseño Web I (SIS-0140) de la UPDS.

- **Sitio publicado:** https://kevinjm-byte.github.io/senderos-samaipata/
- **Tecnologías:** HTML5 semántico, CSS propio (variables, Flexbox, Grid, mobile-first, modo oscuro) y una versión
  alternativa de la portada con Bootstrap 5.3.8 (`version-bootstrap/`).
- **Calidad:** ver `INFORME_CALIDAD.md` (Lighthouse móvil, WCAG 2.2 AA, validación W3C, SEO técnico).

## Estructura
| Carpeta / archivo | Contenido |
|---|---|
| `index.html`, `tours.html`, `galeria.html`, `nosotros.html`, `contacto.html` | Páginas públicas |
| `legal/politicas.html`, `gracias.html`, `404.html` | Páginas de apoyo |
| `css/estilos.css` | Hoja de estilos del sitio |
| `img/`, `video/` | Imágenes optimizadas (WebP) y video con subtítulos |
| `version-bootstrap/` | Prototipo de la portada con Bootstrap |
| `robots.txt`, `sitemap.xml` | SEO técnico |

## Cómo verlo en tu computadora
Abre la carpeta en VS Code y usa Live Server sobre `index.html`.

## Créditos
Contenido: familia Méndez (Senderos Samaipata). Ilustraciones: generadas para el curso, libres de derechos.
Desarrollo: Kevin Jimenez Mano — Diseño Web I, UPDS, 2026.


## Publicación (Lab 14)
1. `git init -b main`
2. `git add .` y revisar que `img/originales/` no aparezca.
3. `git commit -m "Primera versión del sitio de Senderos Samaipata"`
4. Crear el repo público `senderos-samaipata` y `git push -u origin main`.
5. Settings → Pages → Deploy from branch → main / root.
6. Segundo commit: cambiar `https://senderossamaipata.bo/` por `https://kevinjm-byte.github.io/senderos-samaipata/` en canonical, sitemap, robots, Open Graph y JSON-LD. En `404.html` agregar `<base href="/senderos-samaipata/">`.

