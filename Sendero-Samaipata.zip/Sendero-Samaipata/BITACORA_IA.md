# Bitácora de IA — Laboratorio 14

**Nombre:** Kevin Jimenez Mano
**Fecha:** 26/10/2026

| # | Qué le pregunté | Qué me respondió | ¿Lo usé? |
|---|---|---|---|
| 1 | Por qué .gitignore debe excluir img/originales. | Esa carpeta pesa unos 12 MB y GitHub recomienda repos livianos. El sitio ya usa los WebP optimizados. | Sí. |
| 2 | Para qué .nojekyll. | GitHub Pages con Jekyll ignora carpetas que empiezan con _. .nojekyll publica los archivos tal cual. | Archivo vacío creado. |
| 3 | Por qué un segundo commit para la URL. | canonical, sitemap y og:image tienen que ser la dirección real, si no Google y WhatsApp apuntan a un dominio que no es el publicado. | Dejé senderossamaipata.bo hasta tener el usuario. Hay que reemplazarlo después del primer push. |

## Comandos (los corres tú, en tu computadora)
```
git init -b main
git add .
git status
git commit -m "Primera versión del sitio de Senderos Samaipata"
git remote add origin https://github.com/kevinjm-byte/senderos-samaipata.git
git push -u origin main
```
Pages: Settings → Pages → main / (root).
